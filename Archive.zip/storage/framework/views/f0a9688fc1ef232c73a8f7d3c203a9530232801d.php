<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-3 offset-md-9">
        </div>
    </div>
    <div class="row py-2">
        <div class="col-md-12">
            <div class="card">
            <form action="<?php echo e(route('supplier-bill.index')); ?>">
                <div class="card-header">
                    <div class="row">
                      <div class="col-6">
                          <h3 class="card-title">Supplier Bills</h3>

                      </div>
                      <div class="col-5">
                          <input type="text" class="form-control" name="q" placeholder=" Search by Name & Phone">
                      </div>
                      <div class="col-1">
                        <input type="submit" class="btn btn-primary" value="Search">
                      </div>
                    </div>
                  <div>
                  </div>
                </div>
              </form>
                <!-- /.card-header -->
                <div class="card-body">
                  <table class="table table-bordered" id="listTable">
                    <thead>                  
                      <tr>
                        <th style="width: 10px">#</th>
                        <th>Supplier</th>
                        <th>Bill Date</th>
                        <th>Created At</th>
                        <th style="width: 200px">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $supplierBills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplierBill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                            <td><?php echo e($supplierBill->id); ?></td>
                            <td><?php echo e($supplierBill->supplier->name); ?></td>
                            <td><?php echo e($supplierBill->billing_date); ?></td>
                            <td><?php echo e($supplierBill->created_at); ?></td>
                            <td class="d-flex">
                                <a class="btn btn-warning btn-sm m-auto" href="<?php echo e(route('supplier-bill.edit',$supplierBill->id)); ?>"><i class="fas fa-edit"></i>Edit</a>
                                <form action="<?php echo e(route('supplier-bill.destroy',$supplierBill->id)); ?>"
                                    method="POST" class="form form-inline js-confirm">
                                  <?php echo e(method_field('delete')); ?>

                                  <?php echo csrf_field(); ?>
                                  <button class="btn btn-danger btn-sm js-tooltip delete-btn" data-toggle="modal" data-target="#modal-warning"><i class="fas fa-trash-alt"></i> Delete</button>
                                </form>
                            </td>
                          </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                    </tbody>
                  </table>
                </div>
                <!-- /.card-body -->
                <div class="card-footer clearfix">
                        <?php echo e($supplierBills->links()); ?>

                </div>
              </div>
        </div>
    </div>
    <?php echo $__env->make('partials.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/elegantmedia/automobile/resources/views/supplier_bill/index.blade.php ENDPATH**/ ?>