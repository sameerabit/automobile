<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8">
            <div class="card card-secondary">
    <div class="card-header">
      <h3 class="card-title">Show Category</h3>
    </div>
    <!-- /.card-header -->
    <!-- form start -->
<form action="<?php echo e(route('categories.update',$unit->id)); ?>" method="POST" role="form">
      <div class="card-body">
        <div class="form-group">
           <?php echo csrf_field(); ?>
           <?php echo method_field('put'); ?>
           <input type="hidden"  class="form-control" value="<?php echo e($unit->id); ?>" id="id" name="id" >

          <label for="name">Name</label>
          <input type="text"  class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" value="<?php echo e($unit->name); ?>" id="name" name="name" placeholder="Enter Name">
          <?php echo $errors->first('name', '<p class="error invalid-feedback">:message</p>'); ?>

       
        </div>
        <div class="form-group">
           <label for="name">Abbreviation</label>
           <input type="text" class="form-control <?php echo e($errors->has('abbreviation') ? 'is-invalid' : ''); ?>" value="<?php echo e($unit->abbreviation); ?>" id="abbreviation" name="abbreviation" placeholder="Enter Abbreviation">
           <?php echo $errors->first('abbreviation', '<p class="error invalid-feedback">:message</p>'); ?>

         </div>
        <div class="form-group row">
            <div class="col-md-4">
                <label for="description">Description</label>
                <textarea class="form-control text-left <?php echo e($errors->has('description') ? 'is-invalid' : ''); ?>" id="description" name="description" placeholder="Description">
                    <?php echo e($unit->description); ?>

                </textarea>
                <?php echo $errors->first('description', '<p class="error invalid-feedback">:message</p>'); ?>

            </div>
        </div>
      </div>
      <!-- /.card-body -->

      <div class="card-footer">
            <button type="submit" class="btn btn-primary">Update</button>    
        </div>
    </form>
  </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/elegantmedia/automobile/resources/views/unit/edit.blade.php ENDPATH**/ ?>