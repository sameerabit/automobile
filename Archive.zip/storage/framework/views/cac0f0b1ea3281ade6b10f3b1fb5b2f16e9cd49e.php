<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8">
            <div class="card card-secondary">
    <div class="card-header">
      <h3 class="card-title">Show Product</h3>
    </div>
    <!-- /.card-header -->
    <!-- form start -->
<form action="<?php echo e(route('products.update',$product->id)); ?>" method="POST" enctype="multipart/form-data" role="form">
      <div class="card-body">
        <div class="form-group">
            <img height="200px" width="200px;" src="<?php echo e(asset('storage/'.$product->image_url)); ?>" alt="">
        </div>
        <div class="form-group">
           <?php echo csrf_field(); ?>
           <?php echo method_field('put'); ?>
           <input type="hidden"  class="form-control" value="<?php echo e($product->id); ?>" id="id" name="id" >

          <label for="name">Name</label>
          <input type="text"  class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" value="<?php echo e($product->name); ?>" id="name" name="name" placeholder="Enter Name">
          <?php echo $errors->first('name', '<p class="error invalid-feedback">:message</p>'); ?>

       
        </div>
        <div class="form-group">
            <label for="categories">Categories</label>
            <select class="form-control" id="categories" name="category_id">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php if($category->id ==  $product->category_id): ?> selected <?php endif; ?> value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php echo $errors->first('category_id', '<p class="error invalid-feedback">:message</p>'); ?>


          </div>
          <div class="form-group">
            <label for="categories">Brands</label>
            <select class="form-control" id="brands" name="brand_id">
                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php if($brand->id ==  $product->brand_id): ?> selected <?php endif; ?> value="<?php echo e($brand->id); ?>"><?php echo e($brand->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php echo $errors->first('brand_id', '<p class="error invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group row <?php echo e($errors->has('phone') ? 'has-error' : ''); ?>">
            <label for="phone">Image</label>
            <img src="<?php echo e(asset($product->image_url)); ?>" alt="">
            <input type="file" class="form-control <?php echo e($errors->has('image') ? 'is-invalid' : ''); ?>" id="image" name="image" placeholder="Upload an image">
            <?php echo $errors->first('image', '<p class="error invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group row">
            <div class="col-md-4">
                <label for="description">Description</label>
                <textarea class="form-control text-left <?php echo e($errors->has('description') ? 'is-invalid' : ''); ?>" id="description" name="description" placeholder="Description">
                    <?php echo e($product->description); ?>

                </textarea>
                <?php echo $errors->first('description', '<p class="error invalid-feedback">:message</p>'); ?>

            </div>
        </div>
      </div>
      <!-- /.card-body -->

      <div class="card-footer">
            <button type="submit" class="btn btn-primary">Update</button>    
        </div>
    </form>
  </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/elegantmedia/automobile/resources/views/product/edit.blade.php ENDPATH**/ ?>