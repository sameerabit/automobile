<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8">
            <div class="card card-secondary">
    <div class="card-header">
      <h3 class="card-title">Show Supplier</h3>
    </div>
    <!-- /.card-header -->
    <!-- form start -->
<form action="<?php echo e(route('suppliers.store')); ?>" method="POST" role="form">
      <div class="card-body">
        <div class="form-group">
           <?php echo csrf_field(); ?>
          <label for="name">Name (Company/Shop)</label>
          <input type="text" disabled class="form-control" value="<?php echo e($supplier->name); ?>" id="name" name="name" placeholder="Enter Name">
        </div>
        <div class="form-group">
          <label for="exampleInputPassword1">Address</label>
          <input type="text" disabled class="form-control" value="<?php echo e($supplier->address); ?>" id="address" name="address" placeholder="Address">
        </div>

        <div class="form-group row">
            <div class="col-md-4">
                <label for="phone">Phone Number</label>
            <input type="text" disabled class="form-control" value="<?php echo e($supplier->phone); ?>" id="phone" name="phone" placeholder="Phone Number">
            </div>
        </div>
      </div>
      <!-- /.card-body -->

      <div class="card-footer">
        <a class="btn btn-primary btn-lg" href="<?php echo e(route('suppliers.edit',$supplier->id)); ?>" class="btn btn-primary">Edit</a>
      </div>
    </form>
  </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/elegantmedia/automobile/resources/views/supplier/show.blade.php ENDPATH**/ ?>